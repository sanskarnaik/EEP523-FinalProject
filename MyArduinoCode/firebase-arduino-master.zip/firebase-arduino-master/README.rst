FirebaseArduino is a library to simplify connecting to the Firebase database from
arduino clients.

It is a full abstraction of Firebase's REST API exposed through C++ calls in a wiring
friendly way.

ArduinoJson is no longer part of this library and you will have to install latest version
in Arduino environment yourself. (through Board manager or download+unpack from master:
https://github.com/bblanchon/ArduinoJson)

----------------------------------
